import os
import scipy.io
import torch
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from torch.utils.data import Dataset
import urllib.request
from src.utils.data_utils import MultiViewDataset, source_metadata

def load_caltech_data(data_dir="./data/caltech", reduce_dim=True):
    """
    Load Caltech101-7 dataset.
    Downloads .mat file if not present.
    Performs PCA on high-dimensional views if reduce_dim is True.
    """
    if not os.path.exists(data_dir):
        os.makedirs(data_dir)
    
    file_path = os.path.join(data_dir, "Caltech101-7.mat")

    # Mirror URLs for Caltech101-7 .mat file
    # Try multiple sources as some might be 404 or region-blocked
    urls = [
        "https://github.com/ChuanbinZhang/Multi-view-datasets/raw/master/Caltech101-7.mat",
        "https://github.com/SubhadeepNag/Multi-View-Clustering/raw/master/datasets/Caltech101-7.mat", 
        "https://github.com/yeqinglee/mvdata/raw/master/Caltech101-7.mat",
        "https://github.com/ZhiqiangXu/MvC_Data/raw/master/Caltech101-7.mat",
        "https://github.com/Jeaninezpp/Multi-view-clustering/raw/master/Caltech101-7.mat",
        "https://raw.githubusercontent.com/yeqinglee/mvdata/master/Caltech101-7.mat"
    ]
    
    # Check if file exists and is valid
    if os.path.exists(file_path):
        # If file is empty or too small (e.g. < 10KB), it's likely a failed download or 404 html page
        if os.path.getsize(file_path) < 10 * 1024:
            print(f"⚠️ Found corrupt/empty file at {file_path}. Deleting and re-downloading...")
            os.remove(file_path)
            
    if not os.path.exists(file_path):
        print(f"Downloading Caltech101-7 dataset to {file_path}...")
        
        success = False
        for url in urls:
            print(f"Trying source: {url} ...")
            try:
                # Add headers to mimic browser
                opener = urllib.request.build_opener()
                opener.addheaders = [('User-agent', 'Mozilla/5.0')]
                urllib.request.install_opener(opener)
                
                urllib.request.urlretrieve(url, file_path)
                
                # Verify download immediately
                if os.path.getsize(file_path) < 10 * 1024:
                    raise RuntimeError("Downloaded file is too small (likely 404 page).")
                    
                print("Download complete.")
                success = True
                break
            except Exception as e:
                print(f"❌ Failed: {e}")
                if os.path.exists(file_path):
                    os.remove(file_path) # Cleanup partial/corrupt file
        
        if not success:
            raise FileNotFoundError(
                f"All Caltech101-7 downloads failed. Place real data at {file_path}. "
                "Synthetic data is never generated as a fallback."
            )

    # Load .mat file
    try:
        mat = scipy.io.loadmat(file_path)
    except Exception as e:
         raise RuntimeError(f"Failed to load .mat file: {e}")
    
    # Structure of Caltech101-7.mat from yeqinglee/mvdata:
    # X: (1, 6) object array. Each element is (1474, dim)
    # Y: (1474, 1) labels
    
    # Structure Check
    # Support both 'Y' (uppercase) and 'y' (lowercase)
    label_key = 'Y' if 'Y' in mat else ('y' if 'y' in mat else None)
    
    if 'X' not in mat or label_key is None:
         # Fallback check for other versions
         raise ValueError(f"Invalid .mat format: keys 'X' and 'Y'/'y' expected. Found: {list(mat.keys())}")

    raw_X = mat['X']
    
    # Handle Transposed X (some datasets have (1, 6) or (6, 1))
    if raw_X.shape[0] == 6 and raw_X.shape[1] == 1:
        raw_X = raw_X.flatten() # -> (6,)
    elif raw_X.shape[0] == 1 and raw_X.shape[1] == 6:
        raw_X = raw_X[0] # -> (6,)
        
    raw_Y = mat[label_key]     # Labels
    
    # Convert labels
    labels = torch.tensor(raw_Y.flatten(), dtype=torch.long)
    # Ensure 0-based labels
    if labels.min() == 1:
        labels -= 1

    # View names corresponding to the order in common Caltech101-7 versions
    # Order: Gabor(48), WM(40), CENTRIST(254), HOG(1984), GIST(512), LBP(928)
    view_names = ["gabor", "wm", "centrist", "hog", "gist", "lbp"]
    
    processed_views = {}
    scaler = StandardScaler()

    print(f"Preprocessing Caltech101-7 (N={len(labels)})...")
    
    for i, name in enumerate(view_names):
        if i >= len(raw_X):
            break
            
        data = raw_X[i].astype(np.float32)
        original_dim = data.shape[1]
        
        # 1. PCA Dimensionality Reduction
        # Target dim 100 for high-dim views to enable efficient RFF approximation
        if reduce_dim and original_dim > 100:
            target_dim = 100
            print(f"  - View '{name}': PCA {original_dim} -> {target_dim}")
            pca = PCA(n_components=target_dim, random_state=42)
            data = pca.fit_transform(data)
        else:
             print(f"  - View '{name}': Keep dim {original_dim}")
        
        # 2. Standardization
        data = scaler.fit_transform(data)
        processed_views[name] = torch.tensor(data, dtype=torch.float32)

    return MultiViewDataset(processed_views, labels, metadata=source_metadata([file_path]))
